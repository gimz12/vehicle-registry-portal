package rules

import "fmt"

// F2 — stolen-vehicle transfer block (thesis Algorithm 2, step 2).
//
// The rule compares the theft flag and the transfer request for the same vehicle
// at the same moment, so it needs ASSET scope and block commit ordering, and
// nothing else. In the chaincode this fires before the transfer commits and
// rejects it; in the harness it evaluates committed history, so a flagged finding
// means "a transfer was attempted while the vehicle stood flagged".

func init() {
	Register(Descriptor{
		ID:                 "F2",
		Family:             "F2",
		Title:              "Stolen-vehicle check at ownership transfer",
		RequiredCapability: CapabilityAsset,
		Antecedents:        []EventType{EventTransfer},
		CanEvaluate:        canEvaluateTransferHistory,
		Eval:               evalTheftTransfer,
	})
}

func canEvaluateTransferHistory(_ *Ledger, v *Vehicle) Availability {
	if !v.HasCompleteAssetHistory() {
		return Availability{Reason: "theft flags and transfers cannot be joined in this data view"}
	}
	transfers := v.EventsOfType(EventTransfer)
	if len(transfers) == 0 {
		return Availability{Reason: "no TRANSFER record exists for this vehicle"}
	}
	if bestTier(transfers) == E0 {
		return Availability{Reason: "TRANSFER records are self-declared only (E0); no accountable attestation"}
	}
	return Availability{Available: true}
}

func evalTheftTransfer(_ *Ledger, v *Vehicle) []Finding {
	var out []Finding
	stolen := false
	var flagEvent Event

	// Single pass in commit order — the flag's state at the moment of each transfer
	// is what matters, never the flag's state today.
	for _, e := range v.Events {
		switch e.Type {
		case EventTheftFlag:
			stolen, flagEvent = true, e
		case EventTheftClear:
			stolen = false
		case EventTransfer:
			if stolen {
				out = append(out, Finding{
					RuleID:   "F2",
					VID:      v.VID,
					Status:   StatusFlagged,
					Strength: StrengthFor(StrengthAlert, flagEvent, e),
					Tier:     MinTier(flagEvent, e),
					AtSeq:    e.Seq,
					Subject:  SubjectOwner,
					Detail: fmt.Sprintf("ownership transfer attempted while the vehicle was flagged stolen (flag at block %d)",
						flagEvent.Seq),
				})
			}
		}
	}
	return out
}
